# install docker-compose
chmod +x docker-compose
cp ./docker-compose /usr/local/bin/docker-compose
